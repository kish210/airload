@echo off
REM AirLoad Station - offline weight and balance.
REM Binds to loopback only; nothing leaves this machine.
setlocal
set "HERE=%~dp0"
if exist "%HERE%node\node.exe" (
    set "NODE=%HERE%node\node.exe"
) else (
    where node >nul 2>nul || (
        echo Node.js was not found and no runtime is bundled.
        echo Install Node.js 20 or later, or rebuild the bundle with -NodeZip.
        pause
        exit /b 1
    )
    set "NODE=node"
)
echo Starting AirLoad Station...
start "" http://localhost:7801
"%NODE%" "%HERE%app\dist\server.js"
pause
